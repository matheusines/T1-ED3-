#ifndef FUNCIONALIDADES_H
#define FUNCIONALIDADES_H


void funcionalidade1();
void funcionalidade2();
void funcionalidade3();
void funcionalidade4();
void funcionalidade5();
void funcionalidade6();

#endif // FUNCIONALIDADES_H