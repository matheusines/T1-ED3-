#ifndef FUNCOES_UTEIS_H
#define FUNCOES_UTEIS_H
#include <stdio.h>
#include <stdlib.h>


void lerString(FILE *fp, char *dest);



#endif